﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Data.OleDb;

namespace GIP_server
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    TcpListener serverSocket = new TcpListener(350);
                    int verzoekTeller = 0;
                    TcpClient clientSocket = default(TcpClient);
                    serverSocket.Stop();
                    serverSocket.Start();
                    Console.WriteLine(" >> Service beschikbaar.");
                    clientSocket = serverSocket.AcceptTcpClient();
                    Console.WriteLine(" >> Verbinding met cliënt aanvaarden.");
                    verzoekTeller = 0;

                    verzoekTeller += 1;
                    NetworkStream netwerkStream = clientSocket.GetStream();
                    byte[] bytesIn = new byte[100025];

                    netwerkStream.Read(bytesIn, 0, (int)clientSocket.ReceiveBufferSize);

                    string clientData = System.Text.Encoding.ASCII.GetString(bytesIn);
                    clientData = clientData.Substring(0, clientData.IndexOf("$"));
                    string[] data = clientData.Split(new char[] { '&' });

                    Console.WriteLine(" >> Data ontvangen van client: \n{0} \n{1} \n{2} \n{3} \n{4} \n{5} \n{6}", data[0], data[1], data[2], data[3], data[4], data[5], data[6]);
                    string vochtigheid = data[0];
                    string temperatuur = data[1];
                    string lichtsterkte = data[2];
                    string CO2 = data[3];
                    string breedtegraad = data[4];
                    string lengtegraad = data[5];
                    string user = data[6];

                    netwerkStream.Flush();

                    Console.WriteLine(" >> ");
                    clientSocket.Close();
                    serverSocket.Stop();
                    AddData(vochtigheid, temperatuur, lichtsterkte, CO2, breedtegraad, lengtegraad, user);
                }
                catch (NotSupportedException error)
                {
                    Console.WriteLine(error.ToString());
                }
            }
        }
        public void AddUser(string name, string password)
        {

        }

        static void AddData(string vochtigheid, string temperatuur, string lichtsterkte, string CO2, string breedtegraad, string lengtegraad,string user)
        {
            OleDbConnection connection = new OleDbConnection();
            DateTime Tijd = DateTime.Now;
            
            try
            {
                connection.ConnectionString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\5TICT socquet\Documents\GIP\GIP-hub\Website\Website_GIP\Website_GIP\Database.accdb;Persist Security Info = False;";
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "INSERT INTO Waardes(Vochtigheid, Temperatuur, CO2, Lichtsterkte, Gebruiker, Tijd, Breedtegraad, lengtegraad) VALUES ('" + vochtigheid + "','" + temperatuur + "','" + CO2 + "','" + lichtsterkte + "','" + user + "','" + Tijd.ToString() + "','"+ breedtegraad + "','" + lengtegraad + "');";

                command.ExecuteNonQuery();
            }
            catch (OleDbException error)
            {
                Console.WriteLine(error.ToString());
            }
            finally
            {
                connection.Close();
            }
        }
    }
}




